package com.test;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import com.pages.CommonUtilities;
import com.pages.GoogleHomePage;
import com.pages.GoogleSearchResultPage;
import com.setup.BaseClass;

public class TASK2_TC_GoogleSearch extends BaseClass {
	WebDriver driver;
	GoogleHomePage home;
	GoogleSearchResultPage res;
	CommonUtilities com;

	@BeforeClass
	public void setup() {
		driver = getDriver();
		com = new CommonUtilities(driver);
		home = new GoogleHomePage(driver);
		res = new GoogleSearchResultPage(driver);
	}

	@SuppressWarnings("static-access")
	@Test
	public void verifySearch() throws Exception {
		String s = "Software Testing";
		res = home.textToSerach(s);
		Boolean status = res.verifySearchResultPage(s);
		System.out.println("Is the result page appeared? " + status);
		com.scrollDown();
		com.takeScreeshot();
	}
}
