package com.setup;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;

import io.github.bonigarcia.wdm.WebDriverManager;

public class BaseClass {
	private WebDriver driver;
	public WebDriver getDriver() {
		return driver;
	}

	public void initilaize(String browser1, String url) {
		WebDriverManager.chromedriver().setup();
		ChromeOptions options1 = new ChromeOptions();
		options1.addArguments("--start-maximized");// Maximize the browser window
		options1.addArguments("--lang=en-GB");// Sets browser language to english-global
		driver = new ChromeDriver(options1);
		driver.get(url);
	}

	@BeforeClass
	@Parameters({ "browserName", "url" })
	public void setup(@Optional("chrome") String browser, @Optional("http://www.google.com") String url) {
		initilaize(browser, url);
	}	
	//Parameters can be set in the testNG.xml file with <parameter> tag
	//if not found, optional value can be set as above (with @Optional)
	

	@AfterClass
	public void teardown() {
		driver.quit();
	}
}
