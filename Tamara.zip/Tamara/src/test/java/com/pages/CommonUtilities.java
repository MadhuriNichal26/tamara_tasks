package com.pages;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

public class CommonUtilities {
	private WebDriver driver;

	public CommonUtilities(WebDriver driver1) {
		driver = driver1;
	}

	public void scrollDown() {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,1000)");
        System.out.println("Scrolled Down");
	}

	public void takeScreeshot() throws IOException {
		System.getProperty("user.dir");
		File f = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(f, new File("./screenshot.png"));
		System.out.println("ScreenShot Taken");
	}
}
