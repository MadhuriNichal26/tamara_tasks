package com.pages;

import org.openqa.selenium.WebDriver;
import com.setup.BaseClass;

public class GoogleSearchResultPage extends BaseClass {

	private WebDriver driver;

	public GoogleSearchResultPage(WebDriver driver2) {
		driver = driver2;
	}

	public boolean verifySearchResultPage(String s1) {
		String act = driver.getTitle();
		System.out.println("Search Result Page Title " + act);
		if (act.contains(s1)) {
			System.out.println("Search Result page Appeared");
			return true;
		} else {
			return false;
		}
	}
}
