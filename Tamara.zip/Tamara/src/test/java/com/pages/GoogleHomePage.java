package com.pages;

import org.openqa.selenium.By;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

public class GoogleHomePage {
	private static WebDriver driver;

	static By txt_searchBox = By.name("q");

	public GoogleHomePage(WebDriver driver2) {
		driver = driver2;
	}

	public static GoogleSearchResultPage textToSerach(String text) throws Exception {
		GoogleSearchResultPage d1 = null;
		driver.findElement(txt_searchBox).sendKeys(text, Keys.RETURN);
		d1 = new GoogleSearchResultPage(driver);
		return d1;
	}
	
}
